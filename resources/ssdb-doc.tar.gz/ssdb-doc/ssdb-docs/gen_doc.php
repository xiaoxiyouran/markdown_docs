<?php
/*****************************************************
 * A PHP script to parse markdown files, and generate
 * HTML files.
 * @author ideawu
 * @link http://www.ideawu.com/
 

  * Usage:
 *     php gen_doc.php md_dir output_dir
 *****************************************************/
// 是否设置了参数
$input_dir = isset($argv[1])? $argv[1] : '.';
$output_dir = isset($argv[2])? $argv[2] : './output';

// 删除末尾指定字符，默认是删除空白符
$input_dir = rtrim($input_dir, '/');
$output_dir = rtrim($output_dir, '/');


parse_dir($input_dir, $output_dir);

function parse_dir($input_dir, $output_dir, $base_url='.'){
	if(!file_exists($output_dir)){  /// 检查文件或目录是否存在
		mkdir($output_dir);
	}
	$template = "$input_dir/template.php";
	if(!file_exists($template)){
		$template = null;
	}

	$files = scandir($input_dir);
	foreach($files as $file){
		if($file == '.' || $file == '..'){ // 跳过这些目录
			continue;
		}
		$fullpath = "$input_dir/$file";

		if(is_dir($fullpath)){
			$new_output_dir = $output_dir . '/' . $file;
			parse_dir($fullpath, $new_output_dir, "$base_url/..");
		}else{
			$ps = explode('.', $file);   /// 把字符串打散成数组，前面是指定的分隔符。
			$ext = $ps[count($ps) - 1];
			if($ext == 'md'){  			/// 提取扩展名
				gen_doc($fullpath, $output_dir, $template, $base_url);
			}else if(!in_array($ext, array('php'))){   /// 除了.php 文件，其它未能识别的文件直接拷贝过去
				copy($fullpath, "$output_dir/$file");
			}
		}
	}
}

function gen_doc($file, $output_dir, $template=null, $base_url=''){
	$name = str_replace('.md', '', basename($file));  /// basename 返回路径中的文件名部分，如果没有，则返回全部，然后将权文件名中的.md 后缀替换掉
	$markdown = array(
			'name' => $name,
			'input_file' => $file,
			'output_file' => "$output_dir/$name.html",
			'title' => '',
			'html' => '',
			'base_url' => $base_url,
			);

	if(file_exists($markdown['output_file']) && filemtime($file) < filemtime($markdown['output_file'])){
		echo "[skip] {$markdown['output_file']} => {$markdown['output_file']}\n";
		return;
	}

	$in_comment = false;
	$lines = file($file);
	foreach($lines as $line){
		if($line[0] == '`'){
			$in_comment = $in_comment? false:true;
		}
		if($line[0] == '#' && $line[1] != '#' && !$in_comment){
			$line = trim($line);
			$line = trim($line, '#');
			$line = trim($line);
			$markdown['title'] = $line;
		}
	}

	/// 需要安装python的插件，pip install markdown, 会解析出所有内容。
	$cmd = "python -m markdown.__main__ -x tables -x fenced_code -x headerid $file";
	exec($cmd, $result, $retval);
	$markdown['html'] = join("\n", $result);

	if($template){
		ob_start();  // 打开缓冲区
		include($template); // 
		$html = ob_get_clean(); ///返回输出缓冲区的内容，并结束输出缓冲区。如果输出缓冲区不是活跃的，即返回 FALSE 。

	}else{
		$html = default_template($markdown);
	}

	echo "[build] {$markdown['output_file']} => {$markdown['output_file']}\n";
	file_put_contents($markdown['output_file'], $html);
}

function default_template($markdown){
	$html = <<<HTML
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>{$markdown['title']}</title>
	<style type="text/css">
	body{
		font-size: 14px;
		font-family: arial;
		background: #fff;
	}
	</style>
</head>
<body>
	{$markdown['html']}
</body>
</html>
HTML;
	return $html;
}
