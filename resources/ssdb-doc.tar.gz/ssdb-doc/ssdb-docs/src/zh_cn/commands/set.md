# set key value

设置指定 key 的值内容.

## 参数

* `key` - 
* `value` - 

## 返回值

Status reply.

## 示例

	ssdb 127.0.0.1:8888> set a 1
	ok
	(0.000 sec)
