# qrlist name_start name_end limit

类似 [qlist](./qlist.html), 逆序.
