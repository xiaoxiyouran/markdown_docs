# multi_set key1 value1 key2 value2 ...

批量设置一批 key-value.

## 参数

* `key1` -
* `value1` -
* ...

## 返回值

false on error, other values indicate OK.

## 示例
