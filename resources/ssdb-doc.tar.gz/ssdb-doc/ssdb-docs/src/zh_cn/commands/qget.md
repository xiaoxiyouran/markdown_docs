# qget name index

返回指定位置的元素. 0 表示第一个元素, 1 是第二个 ... -1 是最后一个.

## 参数

* `name` - 
* `index` - negative intexes accepted.

## 返回值

false on error, null if no element corresponds to this index, otherwise the item returned.

## 示例
