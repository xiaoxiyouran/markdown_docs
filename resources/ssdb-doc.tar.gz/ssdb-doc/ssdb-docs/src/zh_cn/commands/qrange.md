# qrange offset limit

返回下标处于区域 [offset, offset + limit] 的元素.

## 参数

* `name` - 
* `offset` - 
* `limit` - 

## 返回值

false on error, otherwise an array containing items.

## 示例
