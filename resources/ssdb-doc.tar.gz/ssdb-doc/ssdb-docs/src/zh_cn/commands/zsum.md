# zsum name score_start score_end

返回 key 处于区间 [start,end] 的 score 的和.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
