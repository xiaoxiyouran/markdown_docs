# zrrange name offset limit

类似 [zrange](./zrange.html), 逆序.

## 参数

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
