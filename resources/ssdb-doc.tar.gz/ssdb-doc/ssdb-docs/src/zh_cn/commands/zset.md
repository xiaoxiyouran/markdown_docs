# zset name key score 

设置 zset 中指定 key 对应的权重值.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
