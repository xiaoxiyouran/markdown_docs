# qset name index val

__Since: 1.7.0.0__

更新位于 index 位置的元素. 如果超过现有的元素范围, 会返回错误.

## 参数

* `name` - 
* `index` - negative intexes accepted.
* `val` - 

## 返回值

false on error, other values indicate OK.

## 示例
