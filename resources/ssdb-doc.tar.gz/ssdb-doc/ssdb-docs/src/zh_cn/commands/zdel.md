# zdel name key

获取 zset 中的指定 key.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
