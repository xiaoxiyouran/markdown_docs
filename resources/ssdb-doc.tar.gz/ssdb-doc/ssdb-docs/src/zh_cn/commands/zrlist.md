# zrlist name_start name_end limit

类似 [zlist](./zlist.html), 逆序.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
