# qtrim_front name size

从队列头部删除多个元素.

## 参数

* `name` - 
* `size` - Number of elements to delete.

## 返回值

false on error. Return the number of elements removed.

## 示例
