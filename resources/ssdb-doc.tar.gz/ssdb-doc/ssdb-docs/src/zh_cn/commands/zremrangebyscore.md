# zremrangebyscore name start end

删除权重处于区间 [start,end] 的元素.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
