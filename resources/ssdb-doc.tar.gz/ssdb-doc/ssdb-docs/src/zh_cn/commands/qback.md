# qback name

返回队列的最后一个元素.

## 参数

* `name` - 

## 返回值

false on error, null if queue empty, otherwise the item returned.

## 示例

