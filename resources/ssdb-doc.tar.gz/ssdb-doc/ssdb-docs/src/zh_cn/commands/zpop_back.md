# zpop_back name limit

__Since 1.9.0__

从 zset 首部删除并返回 `limit` 个元素.

## 参数

* `name` - zset 的名字
* `limit` - 

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
