# qslice name begin end

返回下标处于区域 [begin, end] 的元素. begin 和 end 可以是负数

## 参数

* `name` - 
* `begin` - 
* `end` - 

## 返回值

false on error, otherwise an array containing items.

## 示例
