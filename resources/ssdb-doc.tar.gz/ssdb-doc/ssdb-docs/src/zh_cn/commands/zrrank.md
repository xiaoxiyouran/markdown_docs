# zrrank name key

类似 [zrank](./zrank.html), 逆序.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
