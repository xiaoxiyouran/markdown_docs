# qpush_front name item1 item2 ...

往队列的首部添加一个或者多个元素

## 参数

* `name` - 
* `item1` -
* ...

## 返回值

The length of the list after the push operation, false on error.

## 示例
