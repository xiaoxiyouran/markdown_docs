# zlist name_start name_end limit

列出名字处于区间 (name_start, name_end] 的 zset.

("", ""] 表示整个区间.

参见命令 [scan](./scan.html) 对参数的详细解释.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
