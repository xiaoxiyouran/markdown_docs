# multi_zset name key1 score1 key2 score2 ...

批量设置 zset 中的 key-score.

## 参数

* `name` -
* `key1` -
* `score1` -
* ...

## 返回值

false on error, other values indicate OK.

## 示例

