# zrscan name key_start score_start score_end limit

类似 [zscan](./zscan.html), 逆序.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
