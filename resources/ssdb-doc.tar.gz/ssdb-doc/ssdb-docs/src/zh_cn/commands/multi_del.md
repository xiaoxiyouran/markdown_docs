# multi_del key1 key2 ...

批量删除一批 key 和其对应的值内容.

## 参数

* `key1` -
* ...

## 返回值

false on error, other values indicate OK.

## 示例
