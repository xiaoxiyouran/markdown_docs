# strlen key

计算字符串的长度(字节数).

## 参数

* `key` - 

## 返回值

The number of bytes of the string, if key not exists, returns 0.

## 示例
