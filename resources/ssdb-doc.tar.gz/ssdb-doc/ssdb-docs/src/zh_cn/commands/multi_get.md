# multi_get key1 key2 ...

批量获取一批 key 对应的值内容.

## 参数

* `key1` -
* ...

## 返回值

Key-value list.

The keys not found will not be included in the reply, the key-value list is return as: k1 v1 k2 v2 ...

##示例
