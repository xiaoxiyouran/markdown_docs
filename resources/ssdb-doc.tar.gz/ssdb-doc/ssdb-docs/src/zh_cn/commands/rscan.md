# rscan key_start key_end limit

类似 [keys](./scan.html), 逆序.
