# ttl key

返回 key(只针对 KV 类型) 的存活时间.

## 参数

* `key` - 

## 返回值

Time to live of the key, in seconds, -1 if there is no associated expire to the key.

## 示例
