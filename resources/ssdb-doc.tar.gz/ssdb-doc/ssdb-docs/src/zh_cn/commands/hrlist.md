# hrlist name_start name_end limit

类似 [hlist](./hlist.html), 逆序.
