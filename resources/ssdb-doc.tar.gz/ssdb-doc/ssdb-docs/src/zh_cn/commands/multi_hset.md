# multi_hset name key1 value1 key2 value2 ...

批量设置 hashmap 中的 key-value.

## 参数

* `name` - 
* `key1` -
* `value1` -
* ...

## 返回值

false on error, other values indicate OK.

## 示例
