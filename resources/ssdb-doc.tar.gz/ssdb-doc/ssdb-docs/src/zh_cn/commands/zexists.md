# zexists name key

判断指定的 key 是否存在于 zset 中.

## 参数

## 返回值

## 示例

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
