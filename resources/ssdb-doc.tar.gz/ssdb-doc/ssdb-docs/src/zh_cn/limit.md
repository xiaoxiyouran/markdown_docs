# 限制

<table>
	<tr>
		<td>最大 Key 长度</td>
		<td>200 字节</td>
	</tr>
	<tr>
		<td>最大 Value 长度</td>
		<td>31MB</td>
	</tr>
	<tr>
		<td>最大请求或响应长度</td>
		<td>31MB</td>
	</tr>
	<tr>
		<td>单个 HASH 中的元素数量</td>
		<td>9,223,372,036,854,775,807</td>
	</tr>
	<tr>
		<td>单个 ZSET 中的元素数量</td>
		<td>9,223,372,036,854,775,807</td>
	</tr>
	<tr>
		<td>单个 QUEUE 中的元素数量</td>
		<td>9,223,372,036,854,775,807</td>
	</tr>
	<tr>
		<td>命令最多参数个数</td>
		<td>所有参数加起来体积不超过 31MB 大小</td>
	</tr>
</table>
