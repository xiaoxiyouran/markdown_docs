# 集群和分布式

### Twemproxy

SSDB 支持 Redis 协议, 许多人将 Twemproxy 置于多个 SSDB 实例的前端, 实现集群功能.

下载 Twemproxy: [https://github.com/twitter/twemproxy](https://github.com/twitter/twemproxy)

