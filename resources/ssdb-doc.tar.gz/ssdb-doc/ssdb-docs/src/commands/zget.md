# zget name key

Get the score related to the specified key of a zset

## Parameters

* `name` - Name of the zset
* `key` - 

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
