# strlen key

Return the number of bytes of a string.

## Parameters

* `key` - 

## Return Value

The number of bytes of the string, if key not exists, returns 0.

## Example
