# qtrim_back name size

Remove multi elements from the tail of a queue.

## Parameters

* `name` - 
* `size` - Number of elements to delete.

## Return Value

false on error. Return the number of elements removed.

## Example
