# qpush_front name item1 item2 ...

Add one or more than one element to the head of the queue.

## Parameters

* `name` - 
* `item1` -
* ...

## Return Value

The length of the list after the push operation, false on error.

## Example
