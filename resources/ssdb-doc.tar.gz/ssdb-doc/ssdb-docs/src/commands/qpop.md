# qpop name size

Alias of [qpop_front](./qpop_front.html)
