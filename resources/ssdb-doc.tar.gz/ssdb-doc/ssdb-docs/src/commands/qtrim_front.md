# qtrim_front name size

Remove multi elements from the head of a queue.

## Parameters

* `name` - 
* `size` - Number of elements to delete.

## Return Value

false on error. Return the number of elements removed.

## Example
