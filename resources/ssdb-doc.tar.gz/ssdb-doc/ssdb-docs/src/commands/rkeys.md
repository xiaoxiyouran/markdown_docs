# rkeys key_start key_end limit

__Since 1.9.0__

Like [keys](./keys.html), but in reverse order.
