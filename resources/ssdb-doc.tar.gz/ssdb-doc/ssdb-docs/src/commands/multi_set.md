# multi_set key1 value1 key2 value2 ...

Set multiple key-value pairs(kvs) in one method call.

## Parameters

* `key1` -
* `value1` -
* ...

## Return Value

false on error, other values indicate OK.

## Example
