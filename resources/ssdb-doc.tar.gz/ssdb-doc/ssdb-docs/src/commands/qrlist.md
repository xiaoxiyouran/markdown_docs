# qrlist name_start name_end limit

Like [qlist](./qlist.html), but in reverse order.
