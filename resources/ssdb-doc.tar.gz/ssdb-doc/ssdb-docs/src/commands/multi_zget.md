# multi_zget name key1 key2 ...

Get the values related to the specified multiple keys of a zset.

## Parameters

* `name` -
* `key1` -
* ...

## Return Value

Key-value list.

The keys not found will not be included in the reply, the key-value list is return as: k1 v1 k2 v2 ...

## Example