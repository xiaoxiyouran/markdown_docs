# zclear name

Delete all keys in a zset.

## Parameters

* `name` - Name of the zset

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
