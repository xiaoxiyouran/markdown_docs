# zlist name_start name_end limit

List zset names in range `(name_start, name_end]`.

Refer to [scan](./scan.html) command for more information about how it work.

## Parameters

* `name` - Name of the zset
* `name_start` - 
* `name_end` - 
* `limit` - 

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
