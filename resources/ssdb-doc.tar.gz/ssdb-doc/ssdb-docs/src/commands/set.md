# set key value

Set the value of the key.

## Parameters

* `key` - 
* `value` - 

## Return Value

false on error, other values indicate OK.

## Example

