# zincr name key num

Increment the number stored at key in a zset by num.

## Parameters

* `name` - Name of the zset
* `key` - 
* `num` - Must be a signed integer.

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
