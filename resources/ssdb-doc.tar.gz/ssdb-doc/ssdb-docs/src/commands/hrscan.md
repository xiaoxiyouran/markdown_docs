# hrscan name key_start key_end limit

Like [hscan](./hscan.html), but in reverse order.
