# zrrange name offset limit

Returns a range of key-score pairs by index range [offset, offset + limit), in reverse order.

## Parameters

* `name` - Name of the zset

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
