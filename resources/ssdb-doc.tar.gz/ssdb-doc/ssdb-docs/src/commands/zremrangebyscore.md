# zremrangebyscore name start end

Delete the elements of the zset which have score in the range `[start,end]`.

## Parameters

* `name` - Name of the zset

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
