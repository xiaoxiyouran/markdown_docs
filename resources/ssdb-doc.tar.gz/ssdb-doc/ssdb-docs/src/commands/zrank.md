# zrank name key

Returns the rank(index) of a given key in the specified sorted set.

## Parameters

* `name` - Name of the zset
* `key` -

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
