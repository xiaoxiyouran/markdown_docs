# qclear name

Clear the queue.

## Parameters

* `name` - 

## Return Value

false on error.

## Example
