# multi_del key1 key2 ...

Delete specified multiple keys.

## Parameters

* `key1` -
* ...

## Return Value

false on error, other values indicate OK.

## Example
