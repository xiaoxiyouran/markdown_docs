# qslice name begin end

Returns a portion of elements from the queue at the specified range [begin, end]. begin and end could be negative.

## Parameters

* `name` - 
* `begin` - 
* `end` - 

## Return Value

false on error, otherwise an array containing items.

## Example
