# zexists name key

Verify if the specified key exists in a zset.

## Parameters

* `name` - Name of the zset
* `key` - 

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
