# ttl key

Returns the time left to live in seconds, only for keys of KV type.

## Parameters

* `key` - 

## Return Value

Time to live of the key, in seconds, -1 if there is no associated expire to the key.

## Example
