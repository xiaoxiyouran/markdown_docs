# qset name index val

Sets the list element at index to value. An error is returned for out of range indexes.

## Parameters

* `name` - 
* `index` - negative intexes accepted.
* `val` - 

## Return Value

false on error, other values indicate OK.

## Example
