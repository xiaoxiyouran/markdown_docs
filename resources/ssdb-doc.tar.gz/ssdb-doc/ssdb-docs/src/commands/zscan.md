# zscan name key_start score_start score_end limit

List key-score pairs where key-score in range `(key_start+score_start, score_end]`.

Refer to [scan](./scan.html) command for more information about how it work.

## Parameters

* `name` - Name of the zset

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
