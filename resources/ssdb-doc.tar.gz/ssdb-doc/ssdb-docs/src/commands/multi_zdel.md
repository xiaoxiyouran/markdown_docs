# multi_zdel name key1 key2 ...

Delete specified multiple keys of a zset.

## Parameters

* `name` -
* `key1` -
* ...

## Return Value

false on error, other values indicate OK.

## Example
