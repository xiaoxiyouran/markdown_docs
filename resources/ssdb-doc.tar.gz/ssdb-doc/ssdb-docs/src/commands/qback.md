# qback name

Returns the last element of a queue.

## Parameters

* `name` - 

## Return Value

false on error, null if queue empty, otherwise the item returned.

## Example

