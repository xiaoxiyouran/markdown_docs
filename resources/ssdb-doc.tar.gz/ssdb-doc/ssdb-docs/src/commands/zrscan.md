# zrscan name key_start score_start score_end limit

List key-score pairs of a zset, in reverse order. See method [zkeys()](./zkeys.html).

## Parameters

* `name` - Name of the zset

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
