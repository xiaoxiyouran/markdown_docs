# zpop_front name limit

__Since 1.9.0__

Delete and return `limit` element(s) from front of the zset.

## Parameters

* `name` - The name of the zset
* `limit` -

## Return Value

## Example

All SSDB commands are described by [PHP API Doc](http://ssdb.io/docs/php/).
