# qpush_back name item1 item2 ...

Add an or more than one element to the end of the queue.

## Parameters

* `name` - 
* `item1` -
* ...

## Return Value

The length of the list after the push operation, false on error.

## Example
