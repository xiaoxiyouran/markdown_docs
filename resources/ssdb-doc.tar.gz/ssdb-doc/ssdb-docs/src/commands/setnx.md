# setnx key value

Set the string value in argument as value of the key if and only if the key doesn't exist.

## Parameters

* `key` - 
* `value` - 

## Return Value

`1`: value is set, `0`: key already exists.

## Example
