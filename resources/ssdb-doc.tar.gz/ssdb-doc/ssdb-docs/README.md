ssdb-docs
=========

SSDB documentation source code.

## How to build?

PHP cli and Python are required. 
**php install in Ubuntu**
	sudo apt install php



Then, just run

```
make
```

The documentations in HTML format are generated under ```docs/``` directory. Open ```docs/index.html``` with your web browser(Firefox, Chrome, Safari, etc).

## How to contribute?

Fork this repository, create new .md files, edit existing ones, and submit a pull request.

